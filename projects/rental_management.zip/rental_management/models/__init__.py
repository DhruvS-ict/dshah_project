# -*- coding: utf-8 -*-

from . import rental_management
from . import product_template
from . import sale_order
from . import res_partner