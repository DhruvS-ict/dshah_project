# -*- coding: utf-8 -*-

from . import exam
from . import res_config_setting
from . import res_partner
# from . import res_action


